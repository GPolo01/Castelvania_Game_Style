//To load and update the game character animations
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <stdio.h>
#include <stdlib.h>
#include "graphicsResources.h"
#include "character.h"
#include "animation.h"

struct Animation *create_animation(char* path, int num_frames, float t_p_frame){
    if (path == NULL || num_frames == 0) 
        return NULL;
    
    ALLEGRO_BITMAP* sheet = al_load_bitmap(path);
    if (!sheet) {
        fprintf(stderr, "Failed to load spritesheet %s\n", path);
        return NULL;
    }

    struct Animation* anim = malloc(sizeof(struct Animation));
    if(!anim) {
        al_destroy_bitmap(sheet);
        return NULL;
    }

    anim->frames = malloc(sizeof(ALLEGRO_BITMAP*) * num_frames);
    if (!anim->frames) {
        free(anim);
        al_destroy_bitmap(sheet);
        return NULL;
    }

    anim->num_frames = num_frames;
    anim->time_per_frame = t_p_frame;
    anim->current_frame = 0;
    anim->time_accumulated = 0.0f;
    int frame_width = al_get_bitmap_width(sheet) / num_frames;
    int frame_height = al_get_bitmap_height(sheet);

    for (int i = 0; i < num_frames; i++) {
        anim->frames[i] = al_create_sub_bitmap(sheet, i * frame_width, 0, frame_width, frame_height);
        if (!anim->frames[i]) {
            fprintf(stderr, "Failed to create sub-bitmap for frame %d\n", i);
            // if any fail, a loop to destroy previous ones
            for (int j = 0; j < i; j++) {
                al_destroy_bitmap(anim->frames[j]);
            }
            free(anim->frames);
            free(anim);
            al_destroy_bitmap(sheet);
            return NULL;
        }
    }
    return anim;
}

void update_animation_frame(struct Animation* anim, float tempo) {
    if (!anim)
        return;
    
    anim->time_accumulated += tempo;
    //logic to change frame and loop
    if (anim->time_accumulated >= anim->time_per_frame) {
        anim->current_frame++;
        if (anim->current_frame >= anim->num_frames) {
            anim->current_frame = 0; 
        }
        anim->time_accumulated = 0.0f;
    }
}

void destroy_animation(struct Animation* anim) {
    if (!anim) return;
    
    // Gets the "parent" bitmap (the original spritesheet) from the first frame
    ALLEGRO_BITMAP* parent_sheet = al_get_parent_bitmap(anim->frames[0]);

    // Destroys all sub-bitmaps
    for (int i = 0; i < anim->num_frames; i++) {
        if(anim->frames[i]) al_destroy_bitmap(anim->frames[i]);
    }
    if(parent_sheet) al_destroy_bitmap(parent_sheet);

    free(anim->frames);
    free(anim);
}
