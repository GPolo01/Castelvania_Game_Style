#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "character.h"
#include "graphicsResources.h"
#include "animation.h"


int main() {
    // Inicialization of Allegro and its addons
    al_init();
    al_install_keyboard();
    al_install_audio();
    al_install_mouse();
    al_init_font_addon();
    al_init_ttf_addon();
    al_init_image_addon();
    al_init_primitives_addon();
    al_install_audio();
    al_init_acodec_addon();

    if (!al_reserve_samples(1)) {
        fprintf(stderr, "Failed to reserve audio channel");
        return -1;
    }

    struct GameContext* ctx = malloc(sizeof(struct GameContext));
    if (!ctx) {
        fprintf(stderr, "Failed to allocate memory for the game context.\n");
        return -1;
    }
    ctx->display = NULL;
    ctx->difficulty = 0;
    ctx->life = 0;
    ctx->music_volume = 0.5; //max is 1, 0 is mute
    ctx->event_queue = NULL;
    ctx->timer = NULL;
    ctx->default_font = NULL;
    ctx->font = NULL;
    ctx->screen_width = 0;
    ctx->screen_height = 0;
    ctx->menu_image = NULL;
    ctx->settings_image = NULL;
    ctx->menu_image = NULL;
    ctx->boss_music = NULL;
    ctx->menu_music_instanced = NULL;
    ctx->boss_music_instanced = NULL;
    ctx->current_state = STATE_MENU; // Initial state of the game


    // Criation of the main components
    ctx->timer = al_create_timer(1.0 / 30.0);
    ctx->event_queue = al_create_event_queue();

    ctx->default_font = al_load_ttf_font("Personagens_Cenários/Metamorphous/Metamorphous-Regular.ttf", 36, 0);
    if (!ctx->default_font) {
        fprintf(stderr, "Failed to load font.\n");
        return -1;
    }
    ctx->font = al_load_ttf_font("Personagens_Cenários/Metal_Mania/MetalMania-Regular.ttf", 50, 0);
    if (!ctx->font) {
        fprintf(stderr, "Failed to load font.\n");
        return STATE_EXIT;
    }
    
    int widthScreen;
    int heightScreen;
    ALLEGRO_MONITOR_INFO monitor_info;
    // al_get_num_video_adapters() garantes that existes at leats one adapter.
    if (al_get_num_video_adapters() > 0 && al_get_monitor_info(0, &monitor_info)) {
        widthScreen = monitor_info.x2 - monitor_info.x1;
        heightScreen = monitor_info.y2 - monitor_info.y1;
    } else {
        fprintf(stderr, "Failed to get monitor information. Using default resolution 1280x720.\n");
        // Plan B for a common resolution if detection fails
        widthScreen = 1280;
        heightScreen = 720;
    }

    ctx->screen_width = widthScreen;
    ctx->screen_height = heightScreen;

    // Configurations and display creation
    al_set_new_display_flags(ALLEGRO_FULLSCREEN_WINDOW);
    ctx->display = al_create_display(widthScreen, heightScreen);
    if (!ctx->timer || !ctx->display || !ctx->event_queue || !ctx->default_font) {
        fprintf(stderr, "Failed to initialize: Could not create all required components.\n");
        return -1;
    }

    //iniciate image for background menu
    ctx->menu_image = al_load_bitmap("Personagens_Cenários/cenários/fundoMenu.png");
    if (!ctx->menu_image) {
        fprintf(stderr, "Failed to load background image for menu.\n");
        return -1;
    }

    ctx->settings_image = al_load_bitmap("Personagens_Cenários/cenários/Mountain-Dusk.png");
    if (!ctx->settings_image) {
        fprintf(stderr, "Failed to load background image for configuration screen.\n");
        return -1;
    }

    ctx->boss_image = al_load_bitmap("Personagens_Cenários/cenários/Dark-Castle-Hall.png");
    if (!ctx->boss_image) {
        fprintf(stderr, "Failed to load background image for the game.\n");
        return STATE_EXIT;
    }

    //Load musics
    ctx->menu_music = al_load_sample("Personagens_Cenários/Músicas/The-Darkest-Days_Full.ogg");
    if(!ctx->menu_music){
        fprintf(stderr, "Failed to load menu music");
    } else {
        ctx->menu_music_instanced = al_create_sample_instance(ctx->menu_music);
        if (!ctx->menu_music_instanced)
            fprintf(stderr, "Failed to create sample instance for menu music.\n");
        al_set_sample_instance_playmode(ctx->menu_music_instanced, ALLEGRO_PLAYMODE_LOOP);
        al_attach_sample_instance_to_mixer(ctx->menu_music_instanced, al_get_default_mixer());
        al_set_sample_instance_gain(ctx->menu_music_instanced, ctx->music_volume);
    }

    ctx->boss_music = al_load_sample("Personagens_Cenários/Músicas/Thriller_Full.ogg");
    if(!ctx->boss_music){
        fprintf(stderr, "Failed to load boss music");
    } else {
        ctx->boss_music_instanced = al_create_sample_instance(ctx->boss_music);
        if (!ctx->boss_music_instanced)
            fprintf(stderr, "Failed to create sample instance for boss music.\n");
        al_set_sample_instance_playmode(ctx->boss_music_instanced, ALLEGRO_PLAYMODE_LOOP);
        al_attach_sample_instance_to_mixer(ctx->boss_music_instanced, al_get_default_mixer());
        al_set_sample_instance_gain(ctx->boss_music_instanced, ctx->music_volume);
    }

    ctx->extra_music = al_load_sample("Personagens_Cenários/Músicas/Focused-Intensity_Full.ogg");
    if(!ctx->extra_music){
        fprintf(stderr, "Failed to load extra music");
    } else {
        ctx->extra__music_instanced = al_create_sample_instance(ctx->extra_music);
        if (!ctx->extra__music_instanced)
            fprintf(stderr, "Failed to create sample instance for extra music.\n");
        al_set_sample_instance_playmode(ctx->extra__music_instanced, ALLEGRO_PLAYMODE_LOOP);
        al_attach_sample_instance_to_mixer(ctx->extra__music_instanced, al_get_default_mixer());
        al_set_sample_instance_gain(ctx->extra__music_instanced, ctx->music_volume);
    }

    // Register event sources
    al_register_event_source(ctx->event_queue, al_get_display_event_source(ctx->display));
    al_register_event_source(ctx->event_queue, al_get_keyboard_event_source());
    al_register_event_source(ctx->event_queue, al_get_mouse_event_source());
    al_register_event_source(ctx->event_queue, al_get_timer_event_source(ctx->timer));

    al_set_window_title(ctx->display, "A Maldição de Theron");
    al_start_timer(ctx->timer);
    //My game state machine
    while (ctx->current_state != STATE_EXIT) {
        switch (ctx->current_state) {
            case STATE_MENU:
                ctx->current_state = run_menu(ctx);
                break;
            case STATE_SETTINGS:
                ctx->current_state = run_settings(ctx);
                break;
            case STATE_GAME:
                ctx->current_state = run_game(ctx);
                break;
            case STATE_PAUSE:
                ctx->current_state = run_pause(ctx);
                break;
            case STATE_BOSS:
                ctx->current_state = run_boss(ctx);
                break;
            case STATE_VICTORY:
                ctx->current_state = run_victory(ctx);
                break;
            case STATE_GAME_OVER:
                ctx->current_state = run_game_over(ctx);
                break;
            case STATE_EXIT:
                break;
        }
    }

    destroy_all(ctx);
    return 0;
}
