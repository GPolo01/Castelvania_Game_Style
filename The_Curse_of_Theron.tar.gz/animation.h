#ifndef ANIMACAO_H
#define ANIMACAO_H

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>

struct Animation{
    // total frames, time and pointer to the frame array
    int num_frames;
    int current_frame;
    float time_per_frame;
    float time_accumulated;
    ALLEGRO_BITMAP** frames; 
};

struct Animation* create_animation(char* spritesheet_path, int num_frames, float t_p_frame);
void update_animation_frame(struct Animation *anim, float time);
void destroy_animation(struct Animation *anim);

#endif
