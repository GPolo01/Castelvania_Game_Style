// The function is to load and free images, fonts, and game gifs
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_acodec.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_primitives.h>
#include <stdio.h>
#include <stdlib.h>
#include "graphicsResources.h"
#include "character.h"
#include "animation.h"
#include "Bullet.h"

void stop_instanced_music(ALLEGRO_SAMPLE_INSTANCE *instance) {
    if (instance && al_get_sample_instance_playing(instance))
        al_stop_sample_instance(instance);
}

void play_music(ALLEGRO_SAMPLE_INSTANCE *instance, float volume) {
    if (instance) {
        // First, stop if it's already playing 
        if (al_get_sample_instance_playing(instance)) {
            al_stop_sample_instance(instance);
        }
        al_set_sample_instance_gain(instance, volume); 
        al_play_sample_instance(instance);
    }
}

void update_camera(ALLEGRO_BITMAP *stage, float *offset_x, int stage_width, int stage_height, struct GameContext *ctx) {
    // Draws the first part of the background
    al_draw_scaled_bitmap(stage, *offset_x, 0,                      
                        stage_width - *offset_x, stage_height, 0, 0,                            
                        ctx->screen_width - (*offset_x * ( (float)ctx->screen_width / stage_width )), ctx->screen_height, 0);
    // Draws the second part of the background
    al_draw_scaled_bitmap(stage, 0, 0, *offset_x, stage_height,
                        ctx->screen_width - (*offset_x * ( (float)ctx->screen_width / stage_width )), 0,
                        (*offset_x * ( (float)ctx->screen_width / stage_width )), ctx->screen_height, 0);
}

enum GameState run_menu(struct GameContext *ctx) {
    play_music(ctx->menu_music_instanced, ctx->music_volume);
    al_set_window_title(ctx->display, "Menu Inicial");

    // Menu options definition
    char* title_pt = "A Maldição de Theron";
    char* title_en = "The Curse of Theron";
    char* menu_items_pt[] = { "Começar", "Configurações", "Sair" };
    char* menu_items_en[] = { "Start", "Settings", "Exit" };
    int num_items = 3;

    char** menu_items = menu_items_pt;
    int selected = 0;
    bool running, in_portuguese;
    running = in_portuguese = true;
    struct Box language_rect = {ctx->screen_width - 200.0f, ctx->screen_height - 80.0f, ctx->screen_width - 10.0f, ctx->screen_height - 40.0f };

    while (running) {
        ALLEGRO_EVENT event;
        al_wait_for_event(ctx->event_queue, &event);

        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            stop_instanced_music(ctx->menu_music_instanced);
            running = false;
        } else if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (event.keyboard.keycode == ALLEGRO_KEY_DOWN) {
                selected = (selected + 1) % num_items;
            } else if (event.keyboard.keycode == ALLEGRO_KEY_UP) {
                selected = (selected - 1 + num_items) % num_items;
            } else if (event.keyboard.keycode == ALLEGRO_KEY_ENTER) {
                if (selected == 0) {
                    return STATE_GAME;
                } else if (selected == 1) {
                    return STATE_SETTINGS;
                } else if (selected == 2) {
                    stop_instanced_music(ctx->menu_music_instanced);
                    return STATE_EXIT;
                }
            } else if (event.keyboard.keycode == ALLEGRO_KEY_ESCAPE) {
                stop_instanced_music(ctx->menu_music_instanced);
                return STATE_EXIT;
            }
        } else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
            int x = event.mouse.x;
            int y = event.mouse.y;
            // Language Box  
            if (inside_box(x, y, language_rect)) {
                in_portuguese = !in_portuguese; 
                menu_items = in_portuguese ? menu_items_pt : menu_items_en;
            }
        } else if (event.type == ALLEGRO_EVENT_TIMER) {
            al_clear_to_color(al_map_rgb(0, 0, 0));

            if (ctx->menu_image) {
                al_draw_scaled_bitmap(ctx->menu_image, 0, 0, al_get_bitmap_width(ctx->menu_image), 
                    al_get_bitmap_height(ctx->menu_image), 0, 0, ctx->screen_width, ctx->screen_height, 0);  // desenha a imagem de fundo

            } else {
                fprintf(stderr, "Error drawing menu background.\n");
            }

            // Define positions and spacing
            float center_x_screen = ctx->screen_width / 2.0f;
            float shadow_offset = 2.5f;
            float initial_y_menu = ctx->screen_height * 0.35f;
            float espacamento_menu = al_get_font_line_height(ctx->default_font) + 20;

            char* title = in_portuguese ? title_pt : title_en;
            ALLEGRO_COLOR title_color = al_map_rgb(255, 0, 0);
            float title_y = ctx->screen_height * 0.15f;

            al_draw_text(ctx->default_font, al_map_rgb(40, 40, 40),
            center_x_screen + 3, title_y + 3,
            ALLEGRO_ALIGN_CENTRE, title); // shadow
            al_draw_text(ctx->default_font, title_color,
            center_x_screen, title_y,
            ALLEGRO_ALIGN_CENTRE, title);

            for (int i = 0; i < num_items; i++) {
                ALLEGRO_COLOR text_color;
                ALLEGRO_COLOR shadow_color = al_map_rgb(40, 40, 40);
                float y_pos_item = initial_y_menu + i * espacamento_menu;

                if (i == selected) {
                    // Yellow/Orange for selected item
                    text_color = al_map_rgb(255, 200, 0);
                    al_draw_text(ctx->default_font, shadow_color,
                                 center_x_screen + shadow_offset, y_pos_item + shadow_offset,
                                 ALLEGRO_ALIGN_CENTRE, menu_items[i]);
                } else {
                    text_color = al_map_rgb(220, 220, 220);
                }
                al_draw_text(ctx->default_font, text_color,
                             center_x_screen, y_pos_item,
                             ALLEGRO_ALIGN_CENTRE, menu_items[i]);
            }

            // Draws language box in the bottom right corner
            al_draw_filled_rectangle(language_rect.left, language_rect.top, language_rect.right, language_rect.bottom,
                                     al_map_rgb(30, 30, 30));
            al_draw_text(ctx->default_font, al_map_rgb(200, 200, 200), language_rect.left + 5, language_rect.top + 5, 0,
                         in_portuguese ? "Português" : "English");

            al_flip_display();
        }
    }
    return STATE_MENU;
}

enum GameState run_volume_settings(struct GameContext *ctx, bool in_portuguese) {
    char* title_pt = "Ajuste de Volume";
    char* title_en = "Adjust Volume";
    char* current_title = in_portuguese ? title_pt : title_en;

    float center_x_screen = ctx->screen_width / 2.0f;
    float shadow_offset = 2.5f;
    float initial_y = ctx->screen_height * 0.40f;
    float bar_width = 300.0f;
    float bar_height = 20.0f;
    float bar_x = center_x_screen - bar_width / 2.0f;
    float spacing = 60.0f;

    bool running = true;
    while (running) {
        ALLEGRO_EVENT event;
        al_wait_for_event(ctx->event_queue, &event);

        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE){
            stop_instanced_music(ctx->menu_music_instanced);
            return STATE_EXIT;
        } else if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
            switch (event.keyboard.keycode) {
                case ALLEGRO_KEY_LEFT:
                    ctx->music_volume -= 0.05f;
                    if (ctx->music_volume < 0.0f) ctx->music_volume = 0.0f;
                    if (ctx->menu_music_instanced) { 
                        al_set_sample_instance_gain(ctx->menu_music_instanced, ctx->music_volume);
                    }
                    if (ctx->boss_music_instanced) {
                        al_set_sample_instance_gain(ctx->boss_music_instanced, ctx->music_volume);
                    }
                    break;
                case ALLEGRO_KEY_RIGHT:
                    ctx->music_volume += 0.05f;
                    if (ctx->music_volume > 1.0f) ctx->music_volume = 1.0f;
                    // Apply new volume to music instance
                    if (ctx->menu_music_instanced) {
                        al_set_sample_instance_gain(ctx->menu_music_instanced, ctx->music_volume);
                    }
                    if (ctx->boss_music_instanced) {
                        al_set_sample_instance_gain(ctx->boss_music_instanced, ctx->music_volume);
                    }
                    break;
                case ALLEGRO_KEY_ESCAPE:
                case ALLEGRO_KEY_ENTER:
                    return STATE_SETTINGS; // Returns to main settings menu
            }
        } else if (event.type == ALLEGRO_EVENT_TIMER) {
            // Draw background
            al_draw_scaled_bitmap(ctx->settings_image, 0, 0, al_get_bitmap_width(ctx->settings_image),
                                  al_get_bitmap_height(ctx->settings_image), 0, 0, ctx->screen_width, ctx->screen_height, 0);

            // Draw volume submenu title
            ALLEGRO_COLOR title_color = al_map_rgb(255, 255, 0); // Yellow for the title of submenu
            al_draw_text(ctx->font, al_map_rgb(40, 40, 40),
                         center_x_screen + shadow_offset, initial_y - spacing + shadow_offset,
                         ALLEGRO_ALIGN_CENTRE, current_title);
            al_draw_text(ctx->font, title_color,
                         center_x_screen, initial_y - spacing,
                         ALLEGRO_ALIGN_CENTRE, current_title);

            // Draws volume bar
            al_draw_filled_rectangle(bar_x, initial_y, bar_x + bar_width, initial_y + bar_height,
                                     al_map_rgb(50, 50, 50)); // Bar background
            al_draw_filled_rectangle(bar_x, initial_y, bar_x + bar_width * ctx->music_volume, initial_y + bar_height,
                                     al_map_rgb(0, 200, 0)); // Bar fill (green)
            al_draw_rectangle(bar_x, initial_y, bar_x + bar_width, initial_y + bar_height,
                              al_map_rgb(255, 255, 255), 2); // Bar border

            // Draws volume percentage value
            char volume_str[20];
            snprintf(volume_str, sizeof(volume_str), "%d%%", (int)(ctx->music_volume * 100));
            al_draw_text(ctx->default_font, al_map_rgb(255, 255, 255),
                         center_x_screen, initial_y + bar_height + 10,
                         ALLEGRO_ALIGN_CENTRE, volume_str);

            al_flip_display();
        }
    }
    return STATE_SETTINGS;
}

enum GameState run_settings(struct GameContext *ctx) {
    al_draw_scaled_bitmap(ctx->settings_image, 0, 0, al_get_bitmap_width(ctx->settings_image), 
                    al_get_bitmap_height(ctx->settings_image), 0, 0, ctx->screen_width, ctx->screen_height, 0);

    // Setting items definition
    char* title_pt = "Configurações";
    char* title_en = "Settings";
    char* items_pt[] = { "Som", "difficulty", "life", "Retornar" };
    char* items_en[] = { "Sound", "Difficulty", "Life", "Return" };
    char** menu_itens = items_pt; 
    int num_itens = 4;
    int selected = 0;
    // Life submenu
    char* life_opts_pt[] = {"Normal", "Dobro de life", "HitKill"};
    char* life_opts_en[] = {"Normal", "Double life", "HitKill"};
    // Difficulty submenu
    char* diff_opts_pt[] = {"Fácil", "Médio", "Difícil"};
    char* diff_opts_en[] = {"Easy", "Medium", "Hard"};
    int n_vida_opts = 3;
    int n_diff_opts = 3;
    int sub_selected = 0;
    // Define positions and spacing
    float center_x_screen = ctx->screen_width / 2.0f;
    float shadow_offset = 2.5f;
    float initial_y_menu = ctx->screen_height * 0.40f; // Inicitial position menu
    float spacing = 60.0f;

    struct Box language_rect = { ctx->screen_width - 200.0f, ctx->screen_height - 80.0f, ctx->screen_width - 10.0f, ctx->screen_height - 40.0f };
    bool in_portuguese = true;
    bool in_submenu = false;
    bool running = true;
    while(running){
        ALLEGRO_EVENT event;
        al_wait_for_event(ctx->event_queue, &event);

        // Verificação do type de evento
        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            stop_instanced_music(ctx->menu_music_instanced);
            running = 0;
        } else if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (!in_submenu) {
                switch (event.keyboard.keycode) {
                    case ALLEGRO_KEY_DOWN:
                        selected = (selected + 1) % num_itens;
                        break;
                    case ALLEGRO_KEY_UP:
                        selected = (selected - 1 + num_itens) % num_itens;
                        break;
                    case ALLEGRO_KEY_ENTER:
                        if (selected == 0) {
                            enum GameState proximo_estado = run_volume_settings(ctx, in_portuguese);
                            if (proximo_estado == STATE_EXIT) {
                                return STATE_EXIT;
                            }
                        } else if (selected == 1 || selected == 2) {
                            in_submenu = true;
                            sub_selected = (selected == 1) ? ctx->difficulty : ctx->life;
                        } else if (selected == 3) {
                            return STATE_MENU;
                        }
                        break;
                    case ALLEGRO_KEY_ESCAPE:
                        return STATE_MENU;
                }
            } else if (in_submenu){
                // Submenu navigation
                int n_opts = (selected == 1) ? n_vida_opts : n_diff_opts;
                switch (event.keyboard.keycode) {
                    case ALLEGRO_KEY_DOWN:
                        sub_selected = (sub_selected + 1) % n_opts;
                        break;
                    case ALLEGRO_KEY_UP:
                        sub_selected = (sub_selected - 1 + n_opts) % n_opts;
                        break;
                    case ALLEGRO_KEY_ENTER:
                        if (selected == 1) ctx->difficulty = sub_selected;
                        if (selected == 2) ctx->life = sub_selected;
                        in_submenu = false;
                        break;
                    case ALLEGRO_KEY_ESCAPE:
                        in_submenu = false;
                        break;
                }
            } else if (event.keyboard.keycode == ALLEGRO_KEY_ESCAPE) {
                stop_instanced_music(ctx->menu_music_instanced);
                running = 0;  // Close menu with ESC
            }
        } else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
            int x = event.mouse.x;
            int y = event.mouse.y;
            if (inside_box(x, y, language_rect)) {
                in_portuguese = !in_portuguese;
                menu_itens = in_portuguese ? items_pt : items_en;
            }
        } else if (event.type == ALLEGRO_EVENT_TIMER) {
            if (ctx->settings_image) {
                al_draw_scaled_bitmap(ctx->settings_image, 0, 0, al_get_bitmap_width(ctx->settings_image),
                    al_get_bitmap_height(ctx->settings_image), 0, 0, ctx->screen_width, ctx->screen_height, 0);
            } else {
                fprintf(stderr, "Error drawing settings background.\n");
            }

            // Draws title
            char* current_title = in_portuguese ? title_pt : title_en;
            ALLEGRO_COLOR title_color = al_map_rgb(255, 0, 0);
            float title_y = ctx->screen_height * 0.15f;

            al_draw_text(ctx->font, al_map_rgb(40, 40, 40),
            center_x_screen + shadow_offset, title_y + shadow_offset,
            ALLEGRO_ALIGN_CENTRE, current_title);
            al_draw_text(ctx->font, title_color, center_x_screen, title_y,
            ALLEGRO_ALIGN_CENTRE, current_title); // main text

            if (!in_submenu) {
                for (int i = 0; i < num_itens; i++) {
                    ALLEGRO_COLOR text_color;
                    ALLEGRO_COLOR shadow_color = al_map_rgb(40, 40, 40);
                    float y_pos_item = initial_y_menu + i * spacing;

                    if (i == selected) {
                        text_color = al_map_rgb(255, 200, 0);
                        al_draw_text(ctx->default_font, shadow_color,
                                     center_x_screen + shadow_offset, y_pos_item + shadow_offset,
                                     ALLEGRO_ALIGN_CENTRE, menu_itens[i]);
                    } else {
                        text_color = al_map_rgb(220, 220, 220);
                    }
                    al_draw_text(ctx->default_font, text_color,
                                 center_x_screen, y_pos_item,
                                 ALLEGRO_ALIGN_CENTRE, menu_itens[i]);
                }
            } else { // Draws submenu
                char** current_submenu_opts = NULL;
                int current_n_opts = 0;

                if (selected == 1) { // difficulty
                    current_submenu_opts = in_portuguese ? diff_opts_pt : diff_opts_en;
                    current_n_opts = n_diff_opts;
                } else if (selected == 2) { // life
                    current_submenu_opts = in_portuguese ? life_opts_pt : life_opts_en;
                    current_n_opts = n_vida_opts;
                }

                char* submenu_title_pt = (selected == 1) ? "Dificuldade" : "Vida";
                char* submenu_title_en = (selected == 1) ? "Difficulty" : "Life";
                char* current_submenu_title = in_portuguese ? submenu_title_pt : submenu_title_en;

                al_draw_text(ctx->font, al_map_rgb(255, 255, 0),
                             center_x_screen, initial_y_menu - spacing,
                             ALLEGRO_ALIGN_CENTRE, current_submenu_title);

                for (int i = 0; i < current_n_opts; i++) {
                    ALLEGRO_COLOR text_color;
                    ALLEGRO_COLOR shadow_color = al_map_rgb(40, 40, 40);
                    float y_pos_item = initial_y_menu + i * spacing;

                    if (i == sub_selected) {
                        // Green for selected in submenu
                        text_color = al_map_rgb(0, 255, 0); 
                        al_draw_text(ctx->default_font, shadow_color,
                                     center_x_screen + shadow_offset, y_pos_item + shadow_offset,
                                     ALLEGRO_ALIGN_CENTRE, current_submenu_opts[i]);
                    } else {
                        text_color = al_map_rgb(180, 180, 180);
                    }
                    al_draw_text(ctx->default_font, text_color,
                                 center_x_screen, y_pos_item,
                                 ALLEGRO_ALIGN_CENTRE, current_submenu_opts[i]);
                }
            }


            // Draws language box in the bottom right corner
            al_draw_filled_rectangle(language_rect.left, language_rect.top, language_rect.right, language_rect.bottom,
                                     al_map_rgb(30, 30, 30));
            al_draw_text(ctx->font, al_map_rgb(200, 200, 200), language_rect.left + 5, language_rect.top + 5, 0,
                         in_portuguese ? "Português" : "English");

            al_flip_display();
        }
    }
    return STATE_SETTINGS;
}

enum GameState run_victory(struct GameContext *ctx) {
    ALLEGRO_BITMAP *fundo = al_load_bitmap("Personagens_Cenários/cenários/Mountain-Dusk.png");
    if (!fundo) {
        fprintf(stderr, "Error loading background image.\n");
        return STATE_EXIT;
    }

    play_music(ctx->extra__music_instanced, ctx->music_volume);
    al_set_window_title(ctx->display, "Victory!");

    bool in_portuguese = true; // Starts in portuguese
    bool running = true;

    while (running) {
        al_draw_scaled_bitmap(fundo, 0, 0, al_get_bitmap_width(fundo), 
            al_get_bitmap_height(fundo), 0, 0, ctx->screen_width, ctx->screen_height, 0);

        const char *msg1 = in_portuguese ? "Você venceu!!" : "You Won!!";
        const char *msg2 = in_portuguese ? "Pressione ENTER para sair do jogo." : "Press ENTER to quit the game.";

        al_draw_text(ctx->default_font, al_map_rgb(255, 255, 255), ctx->screen_width / 2, ctx->screen_height / 2 - 50, ALLEGRO_ALIGN_CENTER, msg1);
        al_draw_text(ctx->default_font, al_map_rgb(255, 255, 255), ctx->screen_width / 2, ctx->screen_height / 2 + 20, ALLEGRO_ALIGN_CENTER, msg2);

        al_flip_display();

        ALLEGRO_EVENT ev;
        al_wait_for_event(ctx->event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            running = false;
        } else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_ENTER) {
                running = false;
            } else if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) {
                in_portuguese = !in_portuguese;  // Alterna idioma
            }
        }
    }

    al_destroy_bitmap(fundo);
    stop_instanced_music(ctx->extra__music_instanced);
    return STATE_EXIT;
}

enum GameState run_game_over(struct GameContext *ctx) {
    ALLEGRO_BITMAP *fundo = al_load_bitmap("Personagens_Cenários/cenários/Night-Sky.png");
    if (!fundo) {
        fprintf(stderr, "Failed to load background image.\n");
        return STATE_EXIT;
    }

    play_music(ctx->extra__music_instanced, ctx->music_volume);
    al_set_window_title(ctx->display, "Game Over");

    bool in_portuguese = true;
    bool running = true;    
    int num_itens = 2;
    int selected = 0;

    while (running) {
        al_draw_scaled_bitmap(fundo, 0, 0, al_get_bitmap_width(fundo), 
            al_get_bitmap_height(fundo), 0, 0, ctx->screen_width, ctx->screen_height, 0);

        char *title = in_portuguese ? "Você perdeu. Qual sua escolha?" : "You lost. What's your choice?";
        char *items_pt[] = {"Menu Principal", "Sair do jogo"};
        char *items_en[] = {"Main Menu", "Quit Game"};

        al_draw_text(ctx->default_font, al_map_rgb(255, 255, 255), ctx->screen_width / 2, ctx->screen_height / 2 - 100, ALLEGRO_ALIGN_CENTER, title);

        for (int i = 0; i < num_itens; i++) {
            ALLEGRO_COLOR color = (i == selected) ? al_map_rgb(255, 255, 0) : al_map_rgb(200, 200, 200);
            char *text = in_portuguese ? items_pt[i] : items_en[i];
            al_draw_text(ctx->default_font, color, ctx->screen_width / 2, ctx->screen_height / 2 + i * 40, ALLEGRO_ALIGN_CENTER, text);
        }

        al_flip_display();

        ALLEGRO_EVENT ev;
        al_wait_for_event(ctx->event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            running = false;
            al_destroy_bitmap(fundo);
            stop_instanced_music(ctx->extra__music_instanced);
            return STATE_EXIT;
        } else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            switch (ev.keyboard.keycode) {
                case ALLEGRO_KEY_DOWN:
                    selected = (selected + 1) % num_itens;
                    break;
                case ALLEGRO_KEY_UP:
                    selected = (selected - 1 + num_itens) % num_itens;
                    break;
                case ALLEGRO_KEY_ENTER:
                    if (selected == 0) {
                        al_destroy_bitmap(fundo);
                        stop_instanced_music(ctx->extra__music_instanced);
                        return STATE_MENU;
                    } else if (selected == 1) {
                        al_destroy_bitmap(fundo);
                        stop_instanced_music(ctx->extra__music_instanced);
                        return STATE_EXIT;
                    }
                    break;
                case ALLEGRO_KEY_RIGHT:
                    in_portuguese = !in_portuguese;
                    break;
            }
        }
    }

    al_destroy_bitmap(fundo);
    stop_instanced_music(ctx->extra__music_instanced);
    return STATE_EXIT;
}

enum GameState run_game(struct GameContext *ctx) {
    #define MAX_ENEMIES 8       // Máximo de enemies na tela
    #define SPAWN_INTERVAL 1500.0f 
    stop_instanced_music(ctx->menu_music_instanced);
    
    ALLEGRO_BITMAP *stage = al_load_bitmap("Personagens_Cenários/cenários/old-dark-castle.png");
    if (!stage) {
        fprintf(stderr, "Erro ao carregar imagem de fundo do jogo.\n");
        return STATE_EXIT;
    }
    
    // Create array for enemies empty
    struct Character* enemies[MAX_ENEMIES] = {NULL};

    struct Protagonist *hero = create_protagonist(0, 150, ctx->screen_height - 150, ctx->life);
    if (!hero) {
        fprintf(stderr, "Error creating character.\n");
        al_destroy_bitmap(stage);
        return STATE_EXIT;
    }

    ALLEGRO_BITMAP *shot_img = al_load_bitmap("Personagens_Cenários/personagens/TerribleKnight/Sprites/Explosion/explosion.png");
    if (!shot_img) {
        fprintf(stderr, "Error loading shot image.\n");
        return STATE_EXIT;
    }

    ALLEGRO_BITMAP *enemy_shot_img = al_load_bitmap("Personagens_Cenários/personagens/mutant-toad/Sprites/attack/attackshot.png");
    if (!enemy_shot_img) {
        fprintf(stderr, "Error loading enemy shot image.\n");
        return STATE_EXIT;
    }
    // --- World Rules and Constants ---
    bool running, redraw, stage_happening, waiting_enter;
    running = redraw = stage_happening = true;
    waiting_enter = false;
    hero->cooldown_shot = 0.0f;
    int stage_width = al_get_bitmap_width(stage);
    int stage_height = al_get_bitmap_height(stage);
    int dead_toads_count = 0; // only when 6 enemies are kill, you pass to the boss
    float next_spawn = SPAWN_INTERVAL;
    float camera_offset_x = 0.0f;
    float distance_traveled = 0.0f;
    const float SHOT_COOLDOWN = 1.0f;
    const float GRAVITY = 1.0f;
    const float time_delta = 1.0f / 30.0f;
    const float FLOOR_Y = ctx->screen_height - 100.0f;
    const float HERO_SCREEN_X = ctx->screen_width / 3.0f;
    //queue of bullets.
    bullet *bullet_list = NULL;
    ALLEGRO_EVENT ev;

    while (running) {
        al_wait_for_event(ctx->event_queue, &ev);
        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            stop_instanced_music(ctx->menu_music_instanced);
            running = false;
        }
        else if  (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            switch (ev.keyboard.keycode) {
                case ALLEGRO_KEY_RIGHT:
                    hero->control.move_right = true;
                    break;
                case ALLEGRO_KEY_LEFT:
                    hero->control.move_left = true;
                    break;
                case ALLEGRO_KEY_DOWN:
                    hero->control.crouch = true;
                    break;
                case ALLEGRO_KEY_SPACE:
                    hero->control.jump = true;
                    break;
                case ALLEGRO_KEY_UP:
                    hero->control.move_up = true;
                    break;    
                case ALLEGRO_KEY_G:
                    hero->control.shoot = true;
                    break;
                case ALLEGRO_KEY_P: {
                    ctx->current_state = run_pause(ctx);
                    if (ctx->current_state == STATE_MENU) return STATE_MENU;
                    else if (ctx->current_state == STATE_EXIT) return STATE_EXIT;
                    break;
                }
                case ALLEGRO_KEY_ENTER: {
                    if (waiting_enter) {
                        ctx->current_state = STATE_BOSS;
                        running = false; // Return to menu
                    }
                    break;
                }
                case ALLEGRO_KEY_ESCAPE:
                    running = false;
                    break;
            }
        }
        else if (ev.type == ALLEGRO_EVENT_KEY_UP) {
            switch (ev.keyboard.keycode) {
                case ALLEGRO_KEY_RIGHT:
                    hero->control.move_right = false;
                    break;
                case ALLEGRO_KEY_LEFT:
                    hero->control.move_left = false;
                    break;
                case ALLEGRO_KEY_DOWN:
                    hero->control.crouch = false;
                    break;
                case ALLEGRO_KEY_SPACE:
                    hero->control.jump = false;
                    break;
                case ALLEGRO_KEY_UP:
                    hero->control.move_up = false;
                    break;
                case ALLEGRO_KEY_G:
                    hero->control.shoot = false;
                    break;
            }
        }
        else if (ev.type == ALLEGRO_EVENT_TIMER) {
            // 1. update cooldown of hero
            if (hero->cooldown_shot > 0) {
                hero->cooldown_shot -= time_delta;
            }

            update_character_physics(hero, GRAVITY, FLOOR_Y);
            update_character_logic(hero);

            if (hero->current_anim)
                update_animation_frame(hero->current_anim, time_delta);

            // 3. Logic to create the projectile
            if (hero->control.shoot && hero->cooldown_shot <= 0) {
                // Define the initial position of bullet
                float offset_x = hero->facing_right ? 5.0f : -5.0f;
                float offset_y = -85.0f;
                if (hero->control.crouch) offset_y += 30;

                float tiro_x = distance_traveled + offset_x;
                float tiro_y = hero->y  + offset_y;
                unsigned char trajectory = hero->facing_right ? 1 : 0;
                if (hero->control.move_up) trajectory = 2;
                // Create and the put in the list
                bullet *new_bullet = bullet_create(tiro_x, tiro_y, trajectory, bullet_list, 0);

                if (new_bullet) {
                    bullet_list = new_bullet; 
                    hero->cooldown_shot = SHOT_COOLDOWN;
                }
            }

            // 4.Logic to destroy projectiles that goes of screen
            bullet *current = bullet_list;
            bullet *previous = NULL;
            while (current != NULL) {
                float screen_right_limit = distance_traveled + ctx->screen_width;
                float screen_left_limit = distance_traveled - ctx->screen_width;

                bool off_screen = (current->x > screen_right_limit) || (current->x < screen_left_limit);

                if (off_screen) {
                    bullet *to_remove = current;
                    if (previous == NULL) { // if first on the list
                        bullet_list = (bullet*)current->next;
                        current = bullet_list;
                    } else { // if it's in the middle or the end
                        previous->next = current->next;
                        current = (bullet*)current->next;
                    }
                    bullet_destroy(to_remove);
                } else {
                    previous = current;
                    current = (bullet*)current->next;
                }
            }

            // 5. Update camera "wrap-around" and the distance
            if (hero->control.move_right) {
                camera_offset_x += hero->vel_x;
                distance_traveled += hero->vel_x;
            }
            // Restriction: it can only move to the left if's has already gone to the right
            if (hero->control.move_left && distance_traveled > 0) {
                camera_offset_x -= hero->vel_x;
                distance_traveled -= hero->vel_x;
                // Garantes that the travel distance doesn't become negative
                if (distance_traveled < 0) distance_traveled = 0;
            }

            if (camera_offset_x >= stage_width) camera_offset_x -= stage_width;
            if (camera_offset_x < 0) camera_offset_x += stage_width;

            // 6. Logic to spawn enemies
            if (distance_traveled >= next_spawn) {
                // Try to create 2 enemies
                int enemies_created = 0;
                for (int i = 1; i < MAX_ENEMIES && enemies_created < 2; i++) {
                    if (enemies[i] == NULL) { // if slot empty
                        float spawn_x = distance_traveled + ctx->screen_width + (enemies_created * 100); // Aparece na borda direita
                        int type = 1 + (i % 2);
                        enemies[i] = create_character(type, spawn_x, FLOOR_Y, ctx->difficulty);
                        enemies_created++;
                    }
                }
                next_spawn += SPAWN_INTERVAL; // Define the next spawn zone
            }

            // 6.1 update all enemies alive
            for (int i = 0; i < MAX_ENEMIES; i++) {
                if (enemies[i] != NULL) {                    
                    ia_npc(enemies[i], hero, distance_traveled);
                    update_enemy_physics(enemies[i], GRAVITY, FLOOR_Y);
                    update_enemy_logic(enemies[i]);
                    
                    if (enemies[i]->current_anim) {
                        update_animation_frame(enemies[i]->current_anim, time_delta);
                    }

                    //damage by contact with enemie
                    bool hero_hit = check_collision(distance_traveled, hero->y, hero->hitbox_width,
                    hero->hitbox_height, enemies[i]->x, enemies[i]->y,
                    enemies[i]->hitbox_width, enemies[i]->hitbox_height);

                    if (hero_hit) {
                        apply_hero_damage(hero, enemies[i]->damage_sword);
                    }
                    
                    // 6.2. toad shoot logic
                    if (enemies[i]->control.shoot && enemies[i]->on_ground) {
                        // Define initial position of shoot
                        float offset_x = enemies[i]->facing_right ? (enemies[i]->hitbox_width * 0.7f) : -(enemies[i]->hitbox_width * 0.7f);
                        float offset_y = -(enemies[i]->hitbox_height * 0.9f);                 
                        float tiro_x = enemies[i]->x + offset_x;
                        float tiro_y = enemies[i]->y  + offset_y;
                        unsigned char trajectory = enemies[i]->facing_right ? 1 : 0; // 1 para direita, 0 para esquerda

                        // Create new bullet e puts in the begining of the list
                        bullet *enemy_bullet = bullet_create(tiro_x, tiro_y, trajectory, bullet_list, 1);

                        if (enemy_bullet) {
                            bullet_list = enemy_bullet;
                            enemies[i]->control.shoot = false;
                        }
                    }
                    
                }
            }

             // 6.3. Update all the positions for all the bullets
            bullet_move(bullet_list);

            // --- 7. CHECK COLLISIONS: SHOOTS FROM HEROES VS ENEMIES ---
            for (int i = 0; i < MAX_ENEMIES; i++) {
                if (enemies[i] == NULL) continue;

                bullet* current_bullet = bullet_list;
                bullet* prev_bullet = NULL;

                while (current_bullet != NULL) {
                    // The positions are from the world (hero->x, enemies[i]->x, current_bullet->x)
                    if (current_bullet->is_from_hero == 0) {
                        bool hit = check_collision(
                            enemies[i]->x, enemies[i]->y, enemies[i]->hitbox_width, enemies[i]->hitbox_height,
                            current_bullet->x, current_bullet->y, 10, 10 // Hitbox (ex: 10x10 pixels)
                        );
                        //if hit, apply damage to enemie, remove shoot and check if died
                        if (hit) {
                            apply_enemy_damage(enemies[i], hero->damage_shot);    
                            bullet* bullet_to_remove = current_bullet;
                            // Moves the pointer forward before removing, so as not to lose the sequence in the list.
                            current_bullet = (bullet*)current_bullet->next; 

                            if (prev_bullet == NULL) { // If the bullet was the first in the list
                                bullet_list = current_bullet;
                            } else {
                                prev_bullet->next = current_bullet;
                            }
                            bullet_destroy(bullet_to_remove); // free bullet

                            // Check if it died
                            if (enemies[i]->hp <= 0) {
                                destroy_character(enemies[i]);
                                enemies[i] = NULL;
                                dead_toads_count++;
                                printf("Toads dead: %d\n", dead_toads_count);
                                break;
                            }

                        } else {
                            // if not hit, check the next bullet in the list
                            prev_bullet = current_bullet;
                            current_bullet = (bullet*)current_bullet->next;
                        }
                    } else if (current_bullet->is_from_hero == 1) {
                        bool hit = check_collision(
                            distance_traveled, hero->y, hero->hitbox_width, hero->hitbox_height,
                            current_bullet->x, current_bullet->y, 10, 10);
                            //se hit, aplicar dano ao inimigo, remover tiro e verificar se ele morreu
                        if (hit) {
                            apply_hero_damage(hero, enemies[i]->damage_shot);    
                            bullet* bullet_to_remove = current_bullet;
                            current_bullet = (bullet*)current_bullet->next; 

                            if (prev_bullet == NULL) { 
                                bullet_list = current_bullet;
                            } else { 
                                prev_bullet->next = current_bullet;
                            }
                            bullet_destroy(bullet_to_remove); 
                        } else {
                            prev_bullet = current_bullet;
                            current_bullet = (bullet*)current_bullet->next;
                        }
                    }
                }
            }

            // Check condition to game over or to pass to fight boss
            if (hero->hp <= 0) {
                printf("GAME OVER!\n");
                ctx->current_state = STATE_GAME_OVER;
                running = false;
            }
            if (dead_toads_count >= 6) {
                stage_happening = false;
                waiting_enter = true;
            }

            redraw = true;
        }

       // --- Draw on the screen ---
        if (redraw && al_is_event_queue_empty(ctx->event_queue)) {
            redraw = false;
            al_clear_to_color(al_map_rgb(0, 0, 0));

            // --- Draw life bar ---
            float base_hp = get_character_info(0, ctx->difficulty).hp;
            float current_max_hp = base_hp;

            if (ctx->life == 1) current_max_hp = base_hp * 2.0f;
            else if (ctx->life == 2) current_max_hp = 1.0f;

            float hp_percentage = (float)hero->hp / current_max_hp;
            
            float bar_width_max = 200;
            float bar_height = 20;
            float bar_x = 15;
            float barra_y = FLOOR_Y - 800.0f;

            if (stage_happening) update_camera(stage, &camera_offset_x, stage_width, stage_height, ctx);
            else {
                al_draw_scaled_bitmap(stage, 0, 0, al_get_bitmap_width(stage), 
                    al_get_bitmap_height(stage), 0, 0, ctx->screen_width, ctx->screen_height, 0);
                al_draw_text(ctx->font, al_map_rgb(255, 255, 255), ctx->screen_width / 2, ctx->screen_height / 2 - 10, ALLEGRO_ALIGN_CENTER, "Derrotou 6 sapos!");
                al_draw_text(ctx->font, al_map_rgb(255, 0, 0), ctx->screen_width / 2, ctx->screen_height / 2 + 20, ALLEGRO_ALIGN_CENTER, "Pressione ENTER para enfrentar o Chefão"); 
            }
            al_draw_filled_rectangle(bar_x, barra_y, bar_x + (bar_width_max * hp_percentage), barra_y + bar_height, al_map_rgb(0, 200, 0));
            // Draw a border in the bar
            al_draw_filled_rectangle(bar_x, barra_y, bar_x + bar_width_max, barra_y + bar_height, al_map_rgb(150, 0, 0));
            al_draw_filled_rectangle(bar_x, barra_y, bar_x + (bar_width_max * hp_percentage), barra_y + bar_height, al_map_rgb(0, 200, 0));
            al_draw_rectangle(bar_x, barra_y, bar_x + bar_width_max, barra_y + bar_height, al_map_rgb(255, 255, 255), 2);

            //Desenha os personagens na tela e depois os projetéis
            draw_character(hero, HERO_SCREEN_X, hero->y);
            for (int i = 0; i < MAX_ENEMIES; i++) {
                if (enemies[i] != NULL) {
                    float enemy_screen_x = enemies[i]->x - (distance_traveled - HERO_SCREEN_X);
                    draw_enemy(enemies[i], enemy_screen_x, enemies[i]->y);
                }
            }
            for (bullet *b = bullet_list; b != NULL; b = (bullet*)b->next) {
                float bullet_screen_x = b->x - (distance_traveled - HERO_SCREEN_X);
                if (b->is_from_hero == 0) al_draw_bitmap(shot_img, bullet_screen_x, b->y, 0);
                else if (b->is_from_hero == 1) al_draw_bitmap(enemy_shot_img, bullet_screen_x, b->y, 0);
            }
            al_flip_display();
        }
    }

    destroy_protagonist(hero);
    for (int i = 0; i < MAX_ENEMIES; i++) {
        destroy_character(enemies[i]);
    }
    while (bullet_list != NULL) {
        bullet *temp = bullet_list;
        bullet_list = (bullet*)bullet_list->next;
        bullet_destroy(temp);
    }
    al_destroy_bitmap(shot_img);
    al_destroy_bitmap(stage);
    stop_instanced_music(ctx->menu_music_instanced);
    return ctx->current_state;
}

enum GameState run_pause(struct GameContext *ctx) {
    stop_instanced_music(ctx->boss_music_instanced);
    stop_instanced_music(ctx->menu_music_instanced);

    char* itens[] = { "Retornar/Resume", "Voltar ao Menu/Return to Menu", "Sair do Jogo/Quit Game"};
    int n_itens = 3;
    int selected = 0;
    bool running = true;

    while (running) {
        ALLEGRO_EVENT ev;
        al_wait_for_event(ctx->event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            return STATE_EXIT;
        }
        else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            switch (ev.keyboard.keycode) {
                case ALLEGRO_KEY_DOWN:
                    selected = (selected + 1) % n_itens;
                    break;
                case ALLEGRO_KEY_UP:
                    selected = (selected - 1 + n_itens) % n_itens;
                    break;
                case ALLEGRO_KEY_ENTER:
                    switch (selected) {
                        case 0:
                            return STATE_GAME;
                        case 1:
                            return STATE_MENU;
                        case 2: 
                            return STATE_EXIT;
                            break;
                    }
                    break;
                case ALLEGRO_KEY_ESCAPE:
                    return STATE_GAME;
            }
        }
        else if (ev.type == ALLEGRO_EVENT_TIMER) {
            al_clear_to_color(al_map_rgb(0, 0, 0));
            al_draw_filled_rectangle(0, 0, ctx->screen_width, ctx->screen_height, al_map_rgba(0, 0, 0, 180));
            al_draw_text(ctx->font, al_map_rgb(255,255,255),
                         ctx->screen_width/2, ctx->screen_height*0.2,
                         ALLEGRO_ALIGN_CENTRE, "PAUSADO/PAUSED");

            // Items
            float y0 = ctx->screen_height * 0.4;
            float dy = al_get_font_line_height(ctx->font) * 1.2;
            for (int i = 0; i < n_itens; i++) {
                ALLEGRO_COLOR color = (i == selected) ? al_map_rgb(255,200,0) : al_map_rgb(200,200,200);
                al_draw_text(ctx->default_font, color,
                             ctx->screen_width/2, y0 + i*dy,
                             ALLEGRO_ALIGN_CENTRE, itens[i]);
            }
            al_flip_display();
        }
    }
    return STATE_GAME;
}

void generate_ball_attack(bullet **list, float heights[], int num_heights) {
    for (int i = 0; i < num_heights; i++) {
        bullet *new_bullet = bullet_create(0, heights[i], 1, *list, 1);
        if (new_bullet) {
            *list = new_bullet;
        }
    }
}

enum GameState run_boss(struct GameContext *ctx) {
    stop_instanced_music(ctx->menu_music_instanced);
    play_music(ctx->boss_music_instanced, ctx->music_volume);

    ALLEGRO_BITMAP *shot_img = al_load_bitmap("Personagens_Cenários/personagens/TerribleKnight/Sprites/Explosion/explosion.png");
    if (!shot_img) {
        fprintf(stderr, "Error loading shot image.\n");
        return STATE_EXIT;
    }

    struct Protagonist *hero = create_protagonist(0, 150, ctx->screen_height - 150, ctx->life);
    if (!hero) {
        fprintf(stderr, "Error creating Protagonist.\n");
        al_destroy_bitmap(shot_img);
        return STATE_EXIT;
    }

    ALLEGRO_BITMAP *enemy_shot_img = al_load_bitmap("Personagens_Cenários/personagens/demon-Files/Sprites/DemonShot.png");
    if (!enemy_shot_img) {
        fprintf(stderr, "Error loading enemy shot image.\n");
        return STATE_EXIT;
    }

    ALLEGRO_BITMAP *flames = al_load_bitmap("Personagens_Cenários/personagens/demon-Files/Sprites/fire.png");
    if (!flames) {
        fprintf(stderr, "Error loading flame sprites.\n");
    }

    struct Character *boss = create_character(5, ctx->screen_width - 200, ctx->screen_height - 150, ctx->difficulty);
    if (!boss) {
        fprintf(stderr, "Error creating Boss.\n");
        al_destroy_bitmap(shot_img);
        destroy_protagonist(hero);
        return STATE_EXIT;
    }
    
    // --- Rules and World Constants ---
    bool running = true;
    bool redraw = true;
    int stage_width = ctx->screen_width;
    int original_vel = hero->vel_x;
    float flame_width = flames ? al_get_bitmap_width(flames) : 0;
    float flame_height = flames ? al_get_bitmap_height(flames) : 0;
    
    float time_between_attacks = 7.50f;
    float time_boss_special = 3.0f;
    float time_energy_balls = 1.00f;
    float fire_range = ctx->screen_width / 3.0f;
    
    const float SHOT_COOLDOWN = 1.0f;
    hero->cooldown_shot = 0.0f;
    const float GRAVITY = 1.0f;
    const float time_delta = 1.0f / 30.0f;
    const float FLOOR_Y = ctx->screen_height - 100.0f;
    
    bullet *bullet_list = NULL;
 
    // Boss State Machine
    enum BossState { BOSS_ENERGY_BALLS, BOSS_SPECIAL };
    enum BossState boss_state = BOSS_ENERGY_BALLS;

    ALLEGRO_EVENT ev;
    while (running) {
        al_wait_for_event(ctx->event_queue, &ev);
        
        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            stop_instanced_music(ctx->boss_music_instanced);
            running = false;
        }
        else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            switch (ev.keyboard.keycode) {
                case ALLEGRO_KEY_RIGHT: hero->control.move_right = true; break;
                case ALLEGRO_KEY_LEFT:  hero->control.move_left = true; break;
                case ALLEGRO_KEY_DOWN:  hero->control.crouch = true; break;
                case ALLEGRO_KEY_SPACE:
                    // Prevent jumping if inside the flame zone during special attack
                    if (boss_state == BOSS_SPECIAL && hero->x >= fire_range) {
                        hero->control.jump = false;
                    } else {
                        hero->control.jump = true;
                    }
                    break;
                case ALLEGRO_KEY_UP:    hero->control.move_up = true; break;
                case ALLEGRO_KEY_G:     hero->control.shoot = true; break;
                case ALLEGRO_KEY_P: {
                    ctx->current_state = run_pause(ctx);
                    if (ctx->current_state == STATE_MENU || ctx->current_state == STATE_EXIT) 
                        return ctx->current_state;
                    break;
                }
                case ALLEGRO_KEY_ESCAPE: running = false; break;
            }
        }
        else if (ev.type == ALLEGRO_EVENT_KEY_UP) {
            switch (ev.keyboard.keycode) {
                case ALLEGRO_KEY_RIGHT: hero->control.move_right = false; break;
                case ALLEGRO_KEY_LEFT:  hero->control.move_left = false; break;
                case ALLEGRO_KEY_DOWN:  hero->control.crouch = false; break;
                case ALLEGRO_KEY_SPACE: hero->control.jump = false; break;
                case ALLEGRO_KEY_UP:    hero->control.move_up = false; break;
                case ALLEGRO_KEY_G:     hero->control.shoot = false; break;
            }
        }
        else if (ev.type == ALLEGRO_EVENT_TIMER) {
            // 1. Cooldown update
            if (hero->cooldown_shot > 0) hero->cooldown_shot -= time_delta;

            update_character_physics(hero, GRAVITY, FLOOR_Y);
            update_character_logic(hero); 

            if (hero->current_anim) update_animation_frame(hero->current_anim, time_delta);

            // 2. Projectile logic (Hero)
            if (hero->control.shoot && hero->cooldown_shot <= 0) {
                float offset_x = hero->facing_right ? 10.0f : -20.0f;
                float tiro_x = hero->x + offset_x;
                float tiro_y = hero->y + (hero->control.crouch ? -40.0f : -60.0f);
                int trajectory = hero->facing_right ? 1 : 0;
                if (hero->control.move_up) trajectory = 2;
                
                bullet *new_bullet = bullet_create(tiro_x, tiro_y, trajectory, bullet_list, 0);
                if (new_bullet) {
                    bullet_list = new_bullet;
                    hero->cooldown_shot = SHOT_COOLDOWN;
                }
            }

            // 3. Projectile cleanup
            bullet *current = bullet_list;
            bullet *previous = NULL;
            while (current != NULL) {
                bool off_screen = (current->x > ctx->screen_width) || (current->x < 0);
                if (off_screen) {
                    bullet *to_remove = current;
                    if (previous == NULL) bullet_list = (bullet*)current->next;
                    else previous->next = current->next;
                    
                    current = (bullet*)current->next;
                    bullet_destroy(to_remove);
                } else {
                    previous = current;
                    current = (bullet*)current->next;
                }
            }
            
            bullet_move(bullet_list);

            // 4. Boss Attacks
            if (boss_state == BOSS_ENERGY_BALLS) {
                time_between_attacks -= time_delta;
                time_energy_balls -= time_delta;
                
                if (time_energy_balls <= 0) {
                    float heights[3] = { hero->y - 120, hero->y - 20, hero->y - 220 };
                    time_energy_balls = 0.9f;
                    generate_ball_attack(&bullet_list, heights, 3);
                } 
                boss->current_anim = boss->running;

                if (time_between_attacks <= 0) {
                    boss_state = BOSS_SPECIAL;
                    time_boss_special = 3.0f;
                    boss->current_anim = boss->attack_shot;
                }
            } 
            else if (boss_state == BOSS_SPECIAL) {
                time_boss_special -= time_delta;
                boss->current_anim = boss->attack_shot;

                // Fire zone logic
                if (hero->x >= fire_range) {
                    apply_hero_damage(hero, boss->damage_sword);
                    hero->vel_x = original_vel / 1.5f; // Slow down in fire
                }

                if (time_boss_special <= 0) {
                    boss_state = BOSS_ENERGY_BALLS;
                    time_between_attacks = 7.5f;
                    time_energy_balls = 0.9f;
                    hero->vel_x = original_vel;
                }
            }

            // 5. Collision checking
            bullet* bullet_ptr = bullet_list;
            bullet* bullet_prev = NULL;
            while (bullet_ptr != NULL) {
                if (bullet_ptr->is_from_hero == 0) { // Hero attacking Boss
                    if (check_collision(boss->x, boss->y, boss->hitbox_width, boss->hitbox_height,
                                        bullet_ptr->x, bullet_ptr->y, 10, 10)) {
                        apply_enemy_damage(boss, hero->damage_shot);                
                        bullet* to_remove = bullet_ptr;
                        bullet_ptr = (bullet*)bullet_ptr->next; 
                        if (bullet_prev == NULL) bullet_list = bullet_ptr;
                        else bullet_prev->next = bullet_ptr;
                        bullet_destroy(to_remove);
                        continue;
                    }
                } else { // Boss attacking Hero
                    if (check_collision(hero->x, hero->y, hero->hitbox_width, hero->hitbox_height,
                                        bullet_ptr->x, bullet_ptr->y, 10, 10)) {
                        apply_hero_damage(hero, boss->damage_shot);                
                        bullet* to_remove = bullet_ptr;
                        bullet_ptr = (bullet*)bullet_ptr->next; 
                        if (bullet_prev == NULL) bullet_list = bullet_ptr;
                        else bullet_prev->next = bullet_ptr;
                        bullet_destroy(to_remove);
                        continue;
                    }
                }
                bullet_prev = bullet_ptr;
                bullet_ptr = (bullet*)bullet_ptr->next;
            }

            // Contact damage
            if (check_collision(hero->x, hero->y, hero->hitbox_width, hero->hitbox_height,
                                boss->x, boss->y, boss->hitbox_width, boss->hitbox_height)) {
                apply_hero_damage(hero, boss->damage_sword);
            }

            // 6. Win/Loss Conditions
            if (hero->hp <= 0) {
                printf("GAME OVER!\n");
                ctx->current_state = STATE_GAME_OVER;
                running = false;
            }
            if (boss->hp <= 0) {
                printf("BOSS DEFEATED!\n");
                ctx->current_state = STATE_VICTORY;
                running = false;
            } else {
                update_animation_frame(boss->current_anim, time_delta);
            }

            redraw = true;
        }

        // --- RENDER ---
        if (redraw && al_is_event_queue_empty(ctx->event_queue)) {
            redraw = false;
            al_clear_to_color(al_map_rgb(0, 0, 0));

            // Background
            al_draw_scaled_bitmap(ctx->boss_image, 0, 0, al_get_bitmap_width(ctx->boss_image), 
                                 al_get_bitmap_height(ctx->boss_image), 0, 0, ctx->screen_width, ctx->screen_height, 0);

            // Hero HUD
            float base_hp = get_character_info(0, ctx->difficulty).hp;
            float current_max_hp = base_hp;

            // Aplique a mesma lógica que você usou no create_protagonist:
            if (ctx->life == 1) current_max_hp = base_hp * 2.0f;
            else if (ctx->life == 2) current_max_hp = 1.0f;

            float hp_percentage = hero->hp / current_max_hp;
            al_draw_filled_rectangle(15, 20, 215, 40, al_map_rgb(150, 0, 0));
            al_draw_filled_rectangle(15, 20, 15 + (200 * hp_percentage), 40, al_map_rgb(0, 200, 0));
            al_draw_rectangle(15, 20, 215, 40, al_map_rgb(255, 255, 255), 2);

            // Boss HUD
            float boss_max_hp = (float)get_character_info(5, ctx->difficulty).hp;
            float boss_ratio = boss->hp / boss_max_hp;
            al_draw_filled_rectangle(15, 60, ctx->screen_width - 15, 85, al_map_rgb(80, 0, 0));
            al_draw_filled_rectangle(15, 60, 15 + ((ctx->screen_width - 30) * boss_ratio), 85, al_map_rgb(255, 0, 0));
            al_draw_rectangle(15, 60, ctx->screen_width - 15, 85, al_map_rgb(255, 255, 255), 2);
            al_draw_text(ctx->default_font, al_map_rgb(255, 255, 255), ctx->screen_width / 2, ctx->screen_height / 6, ALLEGRO_ALIGN_CENTER, "DEMON KING");

            // Characters
            if (boss->hp > 0) draw_enemy(boss, boss->x, boss->y);
            draw_character(hero, hero->x, hero->y);

            // Bullets
            for (bullet *b = bullet_list; b != NULL; b = (bullet*)b->next) {
                if (b->is_from_hero == 0) al_draw_bitmap(shot_img, b->x, b->y, 0);
                else al_draw_bitmap(enemy_shot_img, b->x, b->y, 0);
            }

            // Special attack effect (flames)
            if (boss_state == BOSS_SPECIAL && flames) {
                for (float x = stage_width; x > fire_range; x -= flame_width) {
                    al_draw_bitmap(flames, x - flame_width, FLOOR_Y - flame_height, 0);
                }
            }
            al_flip_display();
        }
    }

    destroy_protagonist(hero);
    if (boss) destroy_character(boss);
    while (bullet_list != NULL) {
        bullet *temp = bullet_list;
        bullet_list = (bullet*)bullet_list->next;
        bullet_destroy(temp);   
    }
    al_destroy_bitmap(shot_img);
    stop_instanced_music(ctx->boss_music_instanced);
    return ctx->current_state;
}

void destroy_all(struct GameContext *ctx) {
    al_destroy_sample(ctx->menu_music);
    al_destroy_sample(ctx->boss_music);
    al_destroy_sample(ctx->extra_music);
    al_uninstall_audio();

    al_destroy_bitmap(ctx->menu_image);
    al_destroy_bitmap(ctx->settings_image);
    al_destroy_display(ctx->display);
    al_destroy_event_queue(ctx->event_queue);
    al_destroy_timer(ctx->timer);
    al_destroy_font(ctx->default_font);
    al_destroy_font(ctx->font);
    
    al_uninstall_keyboard();
    al_uninstall_mouse();
    al_shutdown_image_addon();
    al_shutdown_font_addon();
    al_shutdown_ttf_addon();
    al_shutdown_primitives_addon();
    
    free(ctx);
}