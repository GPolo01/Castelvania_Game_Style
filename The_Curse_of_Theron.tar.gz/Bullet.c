#include <stdlib.h>
#include "Bullet.h"

bullet* bullet_create(float x, float y, int trajectory, bullet *next, int is_from_hero){			
	//2 is to go up, 1 to go right, 0 to go left
	if ((trajectory < 0) || (trajectory > 2)) return NULL;													
	bullet *new_bullet = (bullet*) malloc(sizeof(bullet));													
	if (!new_bullet) return NULL;
	new_bullet->is_from_hero = is_from_hero;																
	new_bullet->x = x;																						
	new_bullet->y = y;																						
	new_bullet->trajectory = trajectory;																	
	new_bullet->next = (struct bullet*) next;																
	return new_bullet;																						
}

void bullet_move(bullet *elements){																			
	for (bullet *index = elements; index != NULL; index = (bullet*) index->next){							
		if (index->trajectory == 0) index->x -= BULLET_MOVE;											
		else if (index->trajectory == 1) index->x += BULLET_MOVE;
		else if (index->trajectory == 2) index->y -= BULLET_MOVE;															
	}
}

void bullet_destroy(bullet *element){																		
	free(element);																							
}