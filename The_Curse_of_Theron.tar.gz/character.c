#include "character.h"
#include "animation.h"
#include <allegro5/allegro.h>
#include <stdio.h>
#include <math.h>
#include <allegro5/allegro_font.h>

int inside_box(int x, int y, struct Box c) {
    return x >= c.left && x <= c.right && y >= c.top && y <= c.bottom;
}

struct CharacterInfo get_character_info(int type, int difficulty) {
    switch(type) {
        case 0: //Heroi
            return (struct CharacterInfo){.hp = 100, .dmg_shot = 10, .dmg_sword = 0, .width = 40, .height = 140, .scale = 3.5f, .vel_x = 10, .vel_y = 0};
        case 1: case 2:{
            if (difficulty == 0) return (struct CharacterInfo){.hp = 19, .dmg_shot = 5, .dmg_sword = 1, .width = 100, .height = 110, .scale = 3.0f, .vel_x = 8, .vel_y = 0};
            else if (difficulty == 1) return (struct CharacterInfo){.hp = 39, .dmg_shot = 10, .dmg_sword = 1.5, .width = 40, .height = 30, .scale = 3.0f, .vel_x = 8, .vel_y = 0};
            else return (struct CharacterInfo){.hp = 49, .dmg_shot = 15, .dmg_sword = 2, .width = 40, .height = 30, .scale = 3.0f, .vel_x = 8, .vel_y = 0};
        }
        case 5: // Chefão
            if (difficulty == 0) return (struct CharacterInfo){.hp = 140, .dmg_shot = 15, .dmg_sword = 1.0, .width = 300, .height = 400, .scale = 4.0f, .vel_x = 20, .vel_y = 0};
            else if (difficulty == 1) return (struct CharacterInfo){.hp = 180, .dmg_shot = 18, .dmg_sword = 1.2, .width = 300, .height = 400, .scale = 3.0f, .vel_x = 8, .vel_y = 0};
            else return (struct CharacterInfo){.hp = 220, .dmg_shot = 30, .dmg_sword = 2.0, .width = 300, .height = 400, .scale = 3.0f, .vel_x = 8, .vel_y = 0};
        default:
            fprintf(stderr, "Unknown character type.\n");
            return (struct CharacterInfo){.hp = -1, .dmg_shot = -1, .dmg_sword = -1, .width = -1, .height = -1, .scale = -1, .vel_x = -1, .vel_y = -1}; // Retorna valores inválidos
    }
}

void load_protagonist_animation(struct Protagonist *new_p) {
    new_p->idle = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-Idle.png", 4, 0.5);
    new_p->running = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-Run.png", 12, 0.1);
    new_p->running_shot = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-ShotRunning.png", 3, 0.1);
    new_p->attack_shot_up = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-ShotUp.png", 2, 0.2);
    new_p->crouch = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-Crouch.png", 2, 1);
    new_p->crouch_attack = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-CrouchShot.png", 4, 0.25);
    new_p->jump = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-Jump.png", 4, 0.5);
    new_p->jump_attack = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-AirShot.png", 4, 0.20);
    new_p->attack_shot = create_animation("Personagens_Cenários/personagens/TerribleKnight/Spritesheets/player-Shot.png", 4, 0.1);
}

void load_animation(struct Character* new_p, int type) {
    switch(type) {
        case 1: case 2:
            new_p->idle = create_animation("Personagens_Cenários/personagens/mutant-toad/Spritesheets/mutant-toad-idle.png", 4, 0.2);
            new_p->running = create_animation("Personagens_Cenários/personagens/mutant-toad/Spritesheets/mutant-toad-jump.png", 4, 0.4);
            new_p->jump = create_animation(NULL, 0, 0);
            new_p->attack_shot = create_animation("Personagens_Cenários/personagens/mutant-toad/Spritesheets/mutant-toad-attack.png", 3, 0.2);
            new_p->attack_sword = create_animation("Personagens_Cenários/personagens/mutant-toad/Spritesheets/mutant-toad-attack.png", 3, 0.2);
            break;
        case 5: // chefão
            new_p->idle = create_animation("Personagens_Cenários/personagens/demon-Files/Spritesheets/demon-idle.png", 6, 0.4);
            new_p->running = create_animation("Personagens_Cenários/personagens/demon-Files/Spritesheets/demon-idle.png", 6, 0.2);
            new_p->jump = create_animation(NULL, 0, 0);
            new_p->attack_shot = create_animation("Personagens_Cenários/personagens/demon-Files/Spritesheets/teste.png", 3, 0.5);
            new_p->attack_sword = create_animation("Personagens_Cenários/personagens/demon-Files/Spritesheets/demon-attack.png", 8, 0.15);
            break;
        default:
            fprintf(stderr, "Unknown character type.\n");
            return;
    }
    return;
}

struct Protagonist* create_protagonist(int type, float x, float y, int vida) {
    struct CharacterInfo info = get_character_info(type, 0);
    if (info.hp < 0 || info.dmg_shot < 0 || info.dmg_sword < 0) {
        fprintf(stderr, "Erro: type de Character inválido.\n");
        return NULL;
    }


    struct Protagonist *new_p = (struct Protagonist*) malloc(sizeof(struct Protagonist));    
    // Inicializo os ponteiro só por garantia
    new_p->idle = new_p->running = new_p->attack_shot = new_p->running_shot = NULL;
    new_p->jump = new_p->crouch = new_p->crouch_attack = new_p->jump_attack = NULL;
    load_protagonist_animation(new_p);

    new_p->current_anim = new_p->idle;
    if (new_p->current_anim == NULL) {
        fprintf(stderr, "ERRO: Animacao inicial (idle) não foi carregada para o Character type %d\n", type);
        destroy_protagonist(new_p);
        return NULL;
    }
    new_p->x = x; // Position X from Character
    new_p->y = y; // Position Y from Character
    new_p->facing_right = true;
    new_p->on_ground = true;
    new_p->vel_y = info.vel_y;
    new_p->vel_x = info.vel_x;
    new_p->hitbox_height = info.height;
    new_p->hitbox_width = info.width;
    new_p->scale = info.scale;
    if (vida == 0) new_p->hp = info.hp;
    else if (vida == 1) new_p->hp = info.hp * 2.0f;
    else if (vida == 2) new_p->hp = 1; 
    new_p->damage_shot = info.dmg_shot; 
    new_p->damage_sword = info.dmg_sword;
    new_p->control = (struct Joystick){false, false, false, false, false, false, false};
    return new_p;
}

struct Character* create_character(int type, float x, float y, int difficulty) {
    struct CharacterInfo info = get_character_info(type, difficulty);
    if (info.hp < 0 || info.dmg_shot < 0 || info.dmg_sword < 0) {
        fprintf(stderr, "Erro: type de Character inválido.\n");
        return NULL;
    }

    struct Character *inimigo = (struct Character*) malloc(sizeof(struct Character));
        if (inimigo == NULL) {
        fprintf(stderr, "Erro ao alocar memória para o Character.\n");
        return NULL;
    }
    
    inimigo->idle = inimigo->running = inimigo->attack_sword = inimigo->attack_shot = NULL;
    inimigo->jump = inimigo->current_anim = NULL;
    load_animation(inimigo, type);

    inimigo->current_anim = inimigo->idle;
    if (inimigo->current_anim == NULL) {
        fprintf(stderr, "ERRO: Animacao inicial (idle) não foi carregada para o Character type %d\n", type);
        destroy_character(inimigo);
        return NULL;
    }

    inimigo->type = type;
    inimigo->x = x; // Position X from Character
    inimigo->y = y; // Position Y from Character
    inimigo->facing_right = true;
    inimigo->on_ground = true;
    inimigo->vel_y = info.vel_y;
    inimigo->vel_x = info.vel_x;
    inimigo->hitbox_height = info.width;
    inimigo->hitbox_width = info.height;
    inimigo->scale = info.scale;
    inimigo->hp = info.hp; 
    inimigo->damage_shot = info.dmg_shot; 
    inimigo->damage_sword = info.dmg_sword;
    inimigo->control = (struct Joystick){false, false, false, false, false, false, false};
    return inimigo;
}

void update_character_logic(struct Protagonist* p) {
    if (!p) return;
    // animation priority
    if (!p->on_ground) {
        p->current_anim = p->jump;
        if (p->control.shoot)
            p->current_anim = p->jump_attack;
    } else if ((p->control.move_right && p->control.shoot) || (p->control.move_left && p->control.shoot)) {
        p->current_anim = p->running_shot;
    } else if ((p->control.move_right && p->control.move_up && p->control.shoot) || (p->control.move_left && p->control.move_up && p->control.shoot)) {
        p->current_anim = p->attack_shot_up;
    } else if (p->control.move_right || p->control.move_left) {
        p->current_anim = p->running;
    } else if (p->control.crouch) {
        p->current_anim = p->crouch;
        if (p->control.shoot)
            p->current_anim = p->crouch_attack;
    } else if (p->control.shoot) {
        p->current_anim = p->attack_shot;
    } else {
        p->current_anim = p->idle;
    }
    
    if (p->control.move_right) p->facing_right = true;
    if (p->control.move_left) p->facing_right = false;
}

void update_character_physics(struct Protagonist* p, float gravidade, float chao_y) {
    if (!p) return;

    // 1. Horizontal Movement
    if (!p->control.crouch) { // Example: can't move while crouching
        if (p->control.move_right) {
            p->x += p->vel_x;
        }
        if (p->control.move_left) {
            p->x -= p->vel_x;
        }
    }
    
    // 2. Jump Logic
    if (p->control.jump && p->on_ground) {
        p->vel_y = -30.0f; // Jump force
        p->on_ground = false;
    }

    // 3. Gravity
    p->vel_y += gravidade;
    p->y += p->vel_y;

    // 4. Collision with the Ground
    if (p->y >= chao_y) {
        p->y = chao_y;
        p->vel_y = 0;
        p->on_ground = true;
    }
}

void ia_npc(struct Character* p, struct Protagonist* heroi, 
        float dist_heroi_mundo) {
    if (!p || !heroi) return;
    
    float dist_heroi = dist_heroi_mundo - p->x;
    switch (p->type) {
        case 1: case 2: // Toad IA
            // Big Toad Logic: jump towards player according to vision
            p->facing_right = (dist_heroi > 0);
            // 2. Action Decision: only takes decisions if on ground
            if (p->on_ground) {
                if (fabs(dist_heroi) <= 150.0f) {
                    p->control.shoot = p->control.jump = false;
                    p->control.move_right = p->control.move_left = false;
                }
                else if (fabs(dist_heroi) <= 1300.0f && fabs(dist_heroi) > 150.0f) {
                    p->current_anim = p->running;
                    p->control.jump = true;
                    p->control.shoot = true;
                    // Defines direction during jump
                    p->control.move_right = p->facing_right;
                    p->control.move_left = !p->facing_right;
                }
            }
            break;
    }
}

void update_enemy_physics(struct Character* p, float gravidade, float chao_y) {
    if (!p) return;

    if (p->type == 1 || p->type == 2) {
        if (p->control.jump && p->on_ground){
            p->vel_y = -22.0f;
            p->on_ground = false;
        }

        if (!p->on_ground){
            if (p->control.move_right) {
                p->x += p->vel_x;
                p->facing_right = true;
                p->control.move_left = false;
            }
            if (p->control.move_left) {
                p->x -= p->vel_x;
                p->facing_right = p->control.move_right = false;
            }
        }
        p->vel_y += gravidade;
        p->y += p->vel_y;

        // Collision with floor, to not pass through
        if (p->y >= chao_y) {
            p->y = chao_y;
            p->vel_y = 0;
            p->on_ground = true;
            p->control.move_right = p->control.move_left = false;
        }
    } 
    // the boss will stay in the same position
}

void update_enemy_logic(struct Character* p) {
    if (!p) return;

    // animation priority
    switch (p->type) {
        case 1: case 2: {
            if (!p->on_ground) {
                p->current_anim = p->running;
            } else if (p->control.move_right || p->control.move_left) {
                p->current_anim = p->running;
            } else if (p->control.shoot) {
                p->current_anim = p->attack_shot;
            } else {
                p->current_anim = p->idle;
            }
            if (p->control.move_right) p->facing_right = true;
            if (p->control.move_left) p->facing_right = false;
            break;
        }
    }
}

void apply_hero_damage(struct Protagonist *p, int dano) {
    if (!p) return;

    p->hp -= dano;
    if (p->hp < 0) {
        p->hp = 0;
    }
}

void apply_enemy_damage(struct Character *p, int dano) {
    if (!p) return;

    p->hp -= dano;
    if (p->hp < 0) {
        p->hp = 0;
    }
}

bool check_collision(float x1, float y1, float w1, float h1,
                      float x2, float y2, float w2, float h2) {
    // Defines limits of first rectangle
    float metade_w1 = w1 / 2;
    float left1   = x1 - metade_w1;
    float right1  = x1 + metade_w1;
    float top1    = y1 - h1;
    float bottom1 = y1;

    // Defines limits of second rectangle
    float metade_w2 = w2 / 2;
    float left2   = x2 - metade_w2;
    float right2  = x2 + metade_w2;
    float top2    = y2 - h2;
    float bottom2 = y2;

    // Checks collision (overlapping rectangles in X and Y)
    bool colisao_horizontal = right1 >= left2 && left1 <= right2;
    bool colisao_vertical   = bottom1 >= top2 && top1 <= bottom2;

    return colisao_horizontal && colisao_vertical;
}


void draw_character(struct Protagonist* p, float x_screen, float y_screen) {
    if (!p || !p->current_anim) return;

    ALLEGRO_BITMAP* current_frame = p->current_anim->frames[p->current_anim->current_frame];
    if (!current_frame) return;

    // Original dimensions of the spritesheet frame
    float sw = al_get_bitmap_width(current_frame);
    float sh = al_get_bitmap_height(current_frame);
    // applying the scale defined in character info
    float dw = sw * p->scale;
    float dh = sh * p->scale;

    float dx = x_screen - (dw / 2.0f);
    float dy = y_screen - dh; 
    int flags = p->facing_right ? 0 : ALLEGRO_FLIP_HORIZONTAL;
    
    al_draw_scaled_bitmap(current_frame, 0, 0, sw, sh, dx, dy, dw, dh, flags);
}

void draw_enemy(struct Character* p, float x_screen, float y_screen) {
    if (!p || !p->current_anim) return;

    ALLEGRO_BITMAP* current_frame = p->current_anim->frames[p->current_anim->current_frame];
    if (!current_frame) return;

    // Original dimensions of the spritesheet frame
    float sw = al_get_bitmap_width(current_frame);
    float sh = al_get_bitmap_height(current_frame);
    // FINAL dimensions on screen, applying scale
    float dw = sw * p->scale;
    float dh = sh * p->scale;

    float dx = x_screen - (dw / 2.0f);
    float dy = y_screen - dh;
    int flags = p->facing_right ? 0 : ALLEGRO_FLIP_HORIZONTAL;
    
    al_draw_scaled_bitmap(current_frame, 0, 0, sw, sh, dx, dy, dw, dh, flags);
}

void destroy_character(struct Character *p) {
    if (!p) return;

    destroy_animation(p->idle);
    destroy_animation(p->running);
    destroy_animation(p->attack_sword);
    destroy_animation(p->attack_shot);
    destroy_animation(p->jump);
    free(p);
}

void destroy_protagonist(struct Protagonist *p) {
    if (!p) return;
    
    destroy_animation(p->idle);
    destroy_animation(p->running);
    destroy_animation(p->attack_shot);
    destroy_animation(p->jump);
    destroy_animation(p->jump_attack);
    destroy_animation(p->crouch);
    destroy_animation(p->crouch_attack);
    free(p);
}