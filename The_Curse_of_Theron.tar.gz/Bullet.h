#ifndef __BULLET__ 																																
#define __BULLET__																																

#define BULLET_MOVE 12

typedef struct bullet {
	int is_from_hero; //0 form hero, 1 from enemy 																																
	int trajectory;
	float x;																															
	float y;																																																												
	struct bullet *next; 																														
} bullet;																																		

bullet* bullet_create(float x, float y, int trajectory, bullet *next, int is_from_hero);												
void bullet_move(bullet *elements);																													
void bullet_destroy(bullet *element);																											

#endif																																			