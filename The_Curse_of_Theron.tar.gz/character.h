#ifndef CHARACTER_H
#define CHARACTER_H

#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <stdio.h>
#include <stdlib.h>
#include "animation.h"

#define MOVEMENT 20 
#define JUMP 80 

struct Box {
    float left, top, right, bottom;
};

struct Joystick {
    bool move_right;
    bool move_left;
    bool move_up;
    bool slash;
    bool jump;
    bool crouch;
    bool shoot;
};

struct CharacterInfo {
    int hp, dmg_shot, dmg_sword, vel_x, vel_y;
    float width, height, scale;
};

struct Character{
    int hp, damage_shot, damage_sword, vel_x, vel_y, type;
	float hitbox_width, hitbox_height, scale;
    float x, y;	//Position X and Y for the center of the Character  
    struct Animation* idle;
    struct Animation* running;
    struct Animation* attack_sword;
    struct Animation* attack_shot;
    struct Animation* jump;
    struct Animation* current_anim;
    struct Joystick control;
    bool facing_right, on_ground;
};

struct Protagonist{
    int hp, damage_shot, damage_sword, vel_x, vel_y;
	float hitbox_width, hitbox_height, scale, cooldown_shot;
    float x, y;	//Position X and Y for the center of the Character   
    struct Animation* idle;
    struct Animation* running;
    struct Animation* running_shot;
    struct Animation* attack_shot;
    struct Animation* attack_shot_up;
    struct Animation* jump;
    struct Animation* jump_attack;
    struct Animation* crouch;
    struct Animation* crouch_attack;
    struct Animation* current_anim;
    struct Joystick control;
    bool facing_right, on_ground;
};

//auxiliary functions
int inside_box(int x, int y, struct Box c);
struct CharacterInfo get_character_info(int type, int difficulty);
void load_animation(struct Character *new_p, int type);
void load_protagonist_animation(struct Protagonist *new_p);
 
// Modularized update functions
void update_character_logic(struct Protagonist* p);
void ia_npc(struct Character* p, struct Protagonist* heroi, 
        float dist_heroi_mundo);
void update_character_physics(struct Protagonist* p, float gravidade, float chao_y);
void update_enemy_physics(struct Character *p, float gravidade, float chao);
void update_enemy_logic(struct Character* p);

// character creation and movement functions
struct Character* create_character(int type, float x, float y, int difficulty);
struct Protagonist* create_protagonist(int type, float x, float y, int vida);

void draw_character(struct Protagonist* p, float x, float y);
void draw_enemy(struct Character* p, float x, float y);

void apply_hero_damage(struct Protagonist *p, int dano);
void apply_enemy_damage(struct Character *p, int dano);
bool check_collision(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2);

void destroy_character(struct Character *p);
void destroy_protagonist(struct Protagonist *p);

#endif 