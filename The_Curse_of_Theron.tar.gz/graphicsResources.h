#ifndef RECURSOS_GRAFICOS_H
#define RECURSOS_GRAFICOS_H

#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_audio.h>
#include "animation.h"
#include "Bullet.h"

enum GameState{
    STATE_MENU,
    STATE_SETTINGS,
    STATE_GAME,
    STATE_PAUSE,
    STATE_BOSS,
    STATE_VICTORY,
    STATE_GAME_OVER,
    STATE_EXIT
};

struct GameContext {
    // screen dimensions
    int screen_width;      
    int screen_height;
    int difficulty, life;
    enum GameState current_state;
    float music_volume;
    // where the game is drawn, event queue and timer              
    ALLEGRO_DISPLAY* display;
    ALLEGRO_EVENT_QUEUE* event_queue;
    ALLEGRO_TIMER* timer;
    //fonts, images and music           
    ALLEGRO_FONT* default_font;
    ALLEGRO_FONT* font;             
    ALLEGRO_BITMAP* menu_image;
    ALLEGRO_BITMAP* settings_image;
    ALLEGRO_BITMAP* boss_image;
    ALLEGRO_SAMPLE *menu_music;
    ALLEGRO_SAMPLE *boss_music;
    ALLEGRO_SAMPLE* extra_music;
    ALLEGRO_SAMPLE_INSTANCE* extra__music_instanced;
    ALLEGRO_SAMPLE_INSTANCE* menu_music_instanced;
    ALLEGRO_SAMPLE_INSTANCE* boss_music_instanced;
};

enum GameState run_menu( struct GameContext *ctx);
enum GameState run_settings(struct GameContext *ctx);
enum GameState run_volume_settings( struct GameContext *ctx, bool in_portuguese);
enum GameState run_game(struct GameContext *ctx);
enum GameState run_pause(struct GameContext *ctx);
enum GameState run_victory(struct GameContext *ctx);
enum GameState run_game_over(struct GameContext *ctx);
enum GameState run_boss(struct GameContext *ctx);


void generate_ball_attack(bullet **list, float heights[], int num_heights);
void update_map(struct GameContext *ctx, struct Animation *anim, float delta_t); 
void update_camera(ALLEGRO_BITMAP *stage, float *offset_x, int stage_width, int stage_height, struct GameContext *ctx);
void destroy_all(struct GameContext *ctx);
void play_music(ALLEGRO_SAMPLE_INSTANCE *instance, float volume);
void stop_instanced_music(ALLEGRO_SAMPLE_INSTANCE *instance);

#endif
